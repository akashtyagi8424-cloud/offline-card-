YAADON KE PATTE - ANDROID APP PROJECT

यह Android Studio प्रोजेक्ट है। गेम HTML फाइल के रूप में ऐप के अंदर शामिल है,
इसलिए गेम खेलने के लिए इंटरनेट permission या network की जरूरत नहीं है।

APK बनाने के लिए:
1. इस ZIP को कंप्यूटर पर extract करें।
2. Android Studio खोलें और "Open" चुनकर YaadonKePatte फोल्डर चुनें।
3. Gradle sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

ध्यान दें: यह ZIP source project है, पहले से compiled APK नहीं।
Android Studio/Gradle के जरिए APK compile करना जरूरी है।
